HOW TO GET YOUR APK - NO PC / NO ANDROID STUDIO NEEDED (2 mins)

Option A - GitHub (easiest, from your phone):
1. Go to github.com > New repository > name it water-counter > Create
2. Tap 'uploading an existing file' > upload ALL files from this zip (keep folders!)
3. Tap Actions tab > wait 1-2 mins > Build APK finishes
4. Tap the run > Artifacts > Download 'WaterCounter-APK' > unzip > open the .apk on your Honor > Install
5. Long-press home screen > Widgets > Water Counter > drag it on

Option B - PC with Android Studio:
Open this folder in Android Studio > Build > Build App Bundle(s) / APKs > Build APK(s)

Your widget: +Drink / -Decrease on widget itself, target in app, auto-reset midnight, history saved.
