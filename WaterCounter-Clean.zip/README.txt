WATER COUNTER - REAL ANDROID WIDGET (Honor / Android 14)
1. Install Android Studio (free) on PC/Mac.
2. Open this folder WaterCounterWidgetApp as project. Let Gradle sync.
3. Connect Honor phone via USB (enable Developer Options > USB Debugging) OR Build > Build APK > install APK.
4. On phone: long-press home screen > Widgets > Water Counter > drag to home screen.
5. Tap +Drink on widget itself. Tap 'Tap here for settings & history' to open app, set target, see history, decrease.
Daily reset: opens new day -> count 0, history kept. History stored in SharedPreferences, no limit (shows last 100 in app).
