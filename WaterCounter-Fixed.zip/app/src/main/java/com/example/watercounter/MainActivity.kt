package com.example.watercounter
import android.appwidget.AppWidgetManager
import android.content.*
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
class MainActivity: AppCompatActivity(){
 override fun onCreate(s:Bundle?){ super.onCreate(s); setContentView(R.layout.activity_main)
  val prefs=getSharedPreferences("water", MODE_PRIVATE)
  val targetInput=findViewById<EditText>(R.id.targetInput); val countText=findViewById<TextView>(R.id.countText); val hist=findViewById<TextView>(R.id.historyText)
  fun refresh(){ val d=WaterStore.getToday(this); countText.text="${d.count} / ${d.target}  •  ${if(d.target>0) d.count*100/d.target else 0}%"; hist.text=WaterStore.historyText(this) }
  targetInput.setText(prefs.getInt("target",8).toString())
  findViewById<Button>(R.id.saveBtn).setOnClickListener{ val t=(targetInput.text.toString().toIntOrNull()?:8).coerceIn(1,30); WaterStore.setTarget(this,t); refresh(); Toast.makeText(this,"Target saved: $t",Toast.LENGTH_SHORT).show(); WaterWidgetProvider.updateAll(this) }
  findViewById<Button>(R.id.addBtn).setOnClickListener{ WaterStore.add(this); refresh(); WaterWidgetProvider.updateAll(this) }
  findViewById<Button>(R.id.subBtn).setOnClickListener{ WaterStore.sub(this); refresh(); WaterWidgetProvider.updateAll(this) }
  findViewById<Button>(R.id.resetBtn).setOnClickListener{ WaterStore.resetToday(this); refresh(); WaterWidgetProvider.updateAll(this) }
  refresh()
 }
}
