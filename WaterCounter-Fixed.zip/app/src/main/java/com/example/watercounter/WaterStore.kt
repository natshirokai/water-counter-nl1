package com.example.watercounter
import android.content.Context
import java.text.SimpleDateFormat; import java.util.*
object WaterStore{
 data class Day(val count:Int,val target:Int)
 private fun prefs(c:Context)=c.getSharedPreferences("water",Context.MODE_PRIVATE)
 private fun todayKey()=SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(Date())
 fun getToday(c:Context):Day{ val p=prefs(c); val storedDay=p.getString("day",""); val today=todayKey(); if(storedDay!=today){ p.edit().putString("day",today).putInt("count",0).apply(); return Day(0,p.getInt("target",8)) } return Day(p.getInt("count",0),p.getInt("target",8)) }
 fun setTarget(c:Context,t:Int){ prefs(c).edit().putInt("target",t).apply() }
 fun add(c:Context){ val d=getToday(c); val nc=d.count+1; val time=SimpleDateFormat("h:mm a",Locale.getDefault()).format(Date()); val old=prefs(c).getString("history","")?:""; prefs(c).edit().putInt("count",nc).putString("history", old+"\n$todayKey() $time - Glass $nc").apply() }
 fun sub(c:Context){ val d=getToday(c); if(d.count<=0) return; prefs(c).edit().putInt("count",d.count-1).apply() }
 fun resetToday(c:Context){ prefs(c).edit().putInt("count",0).putString("day",todayKey()).apply() }
 fun historyText(c:Context):String{ val h=prefs(c).getString("history","")?:""; return if(h.isBlank()) "No drinks yet." else h.trim().lines().takeLast(100).reversed().joinToString("\n") }
}
