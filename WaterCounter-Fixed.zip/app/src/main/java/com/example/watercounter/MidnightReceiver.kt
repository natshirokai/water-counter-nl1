package com.example.watercounter
import android.content.*
class MidnightReceiver: BroadcastReceiver(){ override fun onReceive(c:Context,i:Intent){ WaterStore.getToday(c); WaterWidgetProvider.updateAll(c) } }
