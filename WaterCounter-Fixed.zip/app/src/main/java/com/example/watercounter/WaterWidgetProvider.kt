package com.example.watercounter
import android.app.PendingIntent; import android.appwidget.*; import android.content.*; import android.widget.RemoteViews
class WaterWidgetProvider: AppWidgetProvider(){
 companion object{
  fun updateAll(c:Context){ val mgr=AppWidgetManager.getInstance(c); val ids=mgr.getAppWidgetIds(ComponentName(c,WaterWidgetProvider::class.java)); ids.forEach{ update(c,mgr,it) } }
  fun update(c:Context,mgr:AppWidgetManager,id:Int){ val d=WaterStore.getToday(c); val pct=if(d.target>0) d.count*100/d.target else 0; val v=RemoteViews(c.packageName,R.layout.widget_layout); v.setTextViewText(R.id.widgetCount,"${d.count} / ${d.target}"); v.setTextViewText(R.id.widgetPct,"$pct%"); v.setProgressBar(R.id.widgetBar,100,pct.coerceIn(0,100),false); v.setOnClickPendingIntent(R.id.widgetAdd, pending(c,"com.example.watercounter.ADD")); v.setOnClickPendingIntent(R.id.widgetSub, pending(c,"com.example.watercounter.SUB")); v.setOnClickPendingIntent(R.id.widgetOpen, pendingOpen(c)); mgr.updateAppWidget(id,v) }
  private fun pending(c:Context,act:String)=PendingIntent.getBroadcast(c,act.hashCode(),Intent(act).setPackage(c.packageName),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
  private fun pendingOpen(c:Context)=PendingIntent.getActivity(c,0,Intent(c,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
 }
 override fun onUpdate(c:Context,mgr:AppWidgetManager,ids:IntArray){ ids.forEach{ update(c,mgr,it) } }
 class ActionReceiver: BroadcastReceiver(){ override fun onReceive(c:Context,i:Intent){ when(i.action){ "com.example.watercounter.ADD"->WaterStore.add(c); "com.example.watercounter.SUB"->WaterStore.sub(c) }; updateAll(c) } }
}
